/* ============================================================================
   彩虹输入框 + 加载光边 —— 几何计算与挂载
   ----------------------------------------------------------------------------
   光边的动画是一圈虚线在胶囊路径上跑。虚线长度与位移都是「路径上的绝对长度」，
   所以换卡片尺寸时必须按真实路径长度重算，不能只改 viewBox。
   这里的做法：由卡片宽高推导出路径与四个区间的长度，再生成一份 keyframes
   注入页面（覆盖 CSS 里那份 320×44 的兜底值）。

   核心量（路径按「上边 → 右端 → 下边 → 左端」顺时针，起点在上边左端切点）：
     LONG  上/下边的直线长度
     CAP   左/右端的长度（两个四分之一弧 + 之间的直线，胶囊时就是半个圆周）
     L     总长 = 2·LONG + 2·CAP
   ============================================================================ */

/** 速度曲线的最小速度（占平均速度的比例）。0.15 → 峰值 2.7，圆头处仍在持续慢走。 */
const MIN_SPEED = 0.15

/** 加速曲线 s(u)：起点与终点速度为 MIN_SPEED / 峰值，且 s(0)=0、s(1)=1。
 *  一次项系数必须等于 1 − 三次项系数，否则每段落不到区间终点。 */
const easeAccel = u => (1 - MIN_SPEED) * u ** 3 + MIN_SPEED * u
/** 减速曲线：加速曲线的镜像 */
const easeDecel = u => 1 - easeAccel(1 - u)

/** 每段取 6 个子段（曲线弯曲较大，密一些才不会看出台阶） */
const SUB_U = [1 / 6, 2 / 6, 3 / 6, 4 / 6, 5 / 6]
const SUB_PCT = SUB_U.map(u => +(u * 25).toFixed(2))

/**
 * 由卡片尺寸推导光边的几何量。
 * @param {object} o
 * @param {number} o.width   卡片宽（CSS 像素）
 * @param {number} o.height  卡片高
 * @param {number} [o.radius] 卡片圆角，默认取 height/2（胶囊）
 * @param {number} [o.bleed]  光带中心线相对卡片边缘再外扩的像素，默认 2
 * @param {number} [o.room]   画布余量（要给模糊留出空间），默认 60
 */
function computeGeometry({ width, height, radius, bleed = 2, room = 60 }) {
  // 光带中心线所在的圆角半径 = 卡片圆角 + 外扩量；圆角不能超过半高
  const r = Math.min(radius ?? height / 2, height / 2) + bleed

  // 光带中心线围成的矩形（在 viewBox 坐标系里，卡片的左上角是 (room, room)）
  const x0 = room - bleed
  const y0 = room - bleed
  const x1 = room + width + bleed
  const y1 = room + height + bleed

  // 上/下边直线长；一个「端」= 两个四分之一弧 + 它们之间的竖直直线
  const LONG = (x1 - x0) - 2 * r
  const CAP = (y1 - y0) - 2 * r + Math.PI * r
  const L = 2 * LONG + 2 * CAP

  // 长边态：整条底边 + 两端各占 1/6 的端；圆头态：一个端的 2/3
  const longLen = LONG + CAP / 3
  const capLen = (CAP * 2) / 3

  // 光带中心每段前进 L/4（相邻两个极值之间正好一格），两端位移随之唯一确定：
  //   前端 + 后端 = 2 × (L/4)，前端 − 后端 = 长度变化量
  const dFront = (L / 2 + (longLen - capLen)) / 2
  const dBack = (L / 2 - (longLen - capLen)) / 2

  // 起点：光带最短（圆头态）时中心正好落在左端中点
  const b0 = 2 * LONG + 1.5 * CAP - capLen / 2

  // 通用圆角矩形路径：把 V 指令写成零长度时就是胶囊（两种情形同一条路径）
  const R = r
  const path = [
    `M${(x0 + R).toFixed(2)} ${y0.toFixed(2)}`,
    `H${(x1 - R).toFixed(2)}`,
    `A${R.toFixed(2)} ${R.toFixed(2)} 0 0 1 ${x1.toFixed(2)} ${(y0 + R).toFixed(2)}`,
    `V${(y1 - R).toFixed(2)}`,
    `A${R.toFixed(2)} ${R.toFixed(2)} 0 0 1 ${(x1 - R).toFixed(2)} ${y1.toFixed(2)}`,
    `H${(x0 + R).toFixed(2)}`,
    `A${R.toFixed(2)} ${R.toFixed(2)} 0 0 1 ${x0.toFixed(2)} ${(y1 - R).toFixed(2)}`,
    `V${(y0 + R).toFixed(2)}`,
    `A${R.toFixed(2)} ${R.toFixed(2)} 0 0 1 ${(x0 + R).toFixed(2)} ${y0.toFixed(2)}`,
    'Z',
  ].join(' ')

  return {
    viewBox: `0 0 ${(width + room * 2).toFixed(2)} ${(height + room * 2).toFixed(2)}`,
    room, path, LONG, CAP, L, longLen, capLen, b0, dFront, dBack,
  }
}

/**
 * 生成可视化的 keyframes 文本（与 CSS 里那份同名，后注入的会覆盖它）。
 * 四段各占 25%：段 1/3 走加速曲线（长度 capLen → longLen），段 2/4 走减速曲线（反向）。
 * 段 3/4 与段 1/2 完全同构，整体前进 L/2。
 */
function buildKeyframes(geo, name = 'rbEdgePulse') {
  const { L, longLen, capLen, b0, dFront, dBack } = geo
  const f0 = b0 + capLen
  const lines = []

  const emit = (pct, start, len, widthVar) => {
    lines.push(
      `  ${pct}% { stroke-dashoffset: ${(-start).toFixed(2)}; ` +
      `stroke-dasharray: ${len.toFixed(2)} ${(L - len).toFixed(2)};` +
      (widthVar ? ` stroke-width: var(${widthVar});` : '') + ' }'
    )
  }

  for (let round = 0; round < 2; round++) {
    // 每一轮跑半圈：先上边（或下边），再右端（或左端），整体偏移 round × L/2
    const off = round * (L / 2)

    // ── 长度增大段：两个边缘都走加速曲线 ──
    emit(round * 50, b0 + off, capLen, '--rb-w-wide')
    SUB_U.forEach((u, i) => {
      const s = easeAccel(u)
      emit(round * 50 + SUB_PCT[i], b0 + off + dBack * s, capLen + (dFront - dBack) * s, null)
    })
    const b1 = b0 + off + dBack
    const f1 = f0 + off + dFront
    emit(round * 50 + 25, b1, longLen, '--rb-w-band')

    // ── 长度减小段：两个边缘都走减速曲线，前后端的位移量互换 ──
    SUB_U.forEach((u, i) => {
      const s = easeDecel(u)
      const b = b1 + dFront * s
      const f = f1 + dBack * s
      emit(round * 50 + 25 + SUB_PCT[i], b, f - b, null)
    })
    const b2 = b1 + dFront
    const f2 = f1 + dBack
    emit(round * 50 + 50, b2, f2 - b2, '--rb-w-wide')
  }

  return `@keyframes ${name} {\n${lines.join('\n')}\n}`
}

/** 四层模糊的 stdDeviation：内层最锐、外层最散，叠出「中间实、外圈散」的柔光 */
const BLUR_STD = [0.75, 1.5, 2.5, 4]

/** 生成光边的 SVG 内容（4 个 filter + 4 条同相位 path） */
function buildSvg(geo, idPrefix = 'rb-edge') {
  const filters = BLUR_STD.map((std, i) => `
      <filter id="${idPrefix}-blur-${i + 1}" x="-60%" y="-260%" width="220%" height="620%"
              colorInterpolationFilters="sRGB">
        <feGaussianBlur stdDeviation="${std}" />
      </filter>`).join('')

  const paths = BLUR_STD.map((_, i) =>
    `      <path class="rb-e${i + 1}" filter="url(#${idPrefix}-blur-${i + 1})" d="${geo.path}" />`
  ).join('\n')

  return [
    `<svg viewBox="${geo.viewBox}">`,
    '  <defs>' + filters,
    '  </defs>',
    '  <g>',
    paths,
    '  </g>',
    '</svg>',
  ].join('\n')
}

/**
 * 把光边渲染进一个 .rb-edge 元素：替换尺寸、生成 SVG、注入按真实路径长度算出来的 keyframes。
 * 换卡片尺寸时重新调用即可（旧的 keyframes 会被同名覆盖）。
 */
function renderEdge(edgeEl, geo, { keyframeName = 'rbEdgePulse' } = {}) {
  // 画布余量与 CSS 里的 --rb-room 必须一致，否则 SVG 会被拉伸
  edgeEl.style.setProperty('--rb-room', `${geo.room}px`)
  edgeEl.innerHTML = buildSvg(geo)

  const styleId = `${keyframeName}-dynamic`
  let styleEl = document.getElementById(styleId)
  if (!styleEl) {
    styleEl = document.createElement('style')
    styleEl.id = styleId
    document.head.appendChild(styleEl)
  }
  styleEl.textContent = buildKeyframes(geo, keyframeName)
  return geo
}

if (typeof window !== 'undefined') {
  window.RainbowPill = { computeGeometry, buildKeyframes, buildSvg, renderEdge, MIN_SPEED }
}
