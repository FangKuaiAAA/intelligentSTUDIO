# 几何与尺寸参数化

## 层次结构（顺序与 z-index 不能改）

```
.rb-slot                     尺寸真源：--rb-w / --rb-h
└── .rb-pill                 isolation:isolate，形成独立层叠上下文
    ├── (::before)           彩虹底层   z-index:-1  conic-gradient + blur(8px)
    ├── .rb-pill-surface     白色磨砂面 z-index: 1  把光边内圈遮住
    ├── .rb-pill-icon/text   内容       z-index: 3
    └── .rb-edge             加载光边   z-index: 0  绝对定位并向外扩 --rb-room
```

两个要点：

1. `.rb-pill` 必须有 `isolation: isolate`，否则 `::before` 的 `z-index: -1` 会跑到卡片背后而看不见。
2. `.rb-edge` 必须在磨砂面**之下**。光边的内圈被磨砂面挡住，只有溢出到卡片外的部分可见 —— 这就是「贴着边框向外发光」而不是「画了一圈亮线」的原因。不要用 `clip-path` 去裁内圈，那会把模糊一起切出硬边。

## 尺寸参数

| 变量 | 含义 | 默认 |
|---|---|---|
| `--rb-w` / `--rb-h` | 卡片宽高 | `320px` / `44px` |
| `--rb-radius` | 卡片圆角 | `999px`（胶囊） |
| `--rb-bleed` | 光带中心线相对卡片边缘再外扩 | `2px` |
| `--rb-room` | 画布余量，光边容器四周各外扩这么多 | `60px` |
| `--rb-edge-duration` | 光边绕一圈的时间 | `3s` |
| `--rb-rainbow-duration` | 彩虹转一圈的时间 | `12s` |

`--rb-room` 必须大于「最大模糊的可见扩散 + 光边最粗时的一半」。四层模糊的 `stdDeviation` 最大为 4（约 12px 可见扩散），光边最粗 21px（半宽约 10px），所以 60 足够。调大模糊半径时要同步放大它，否则光晕会被 SVG 视口裁掉。

## 路径生成

光带中心线围成一个圆角矩形：卡片左上角在 viewBox 坐标里是 `(room, room)`，外扩 `bleed` 后得到 `(x0,y0)`–`(x1,y1)`，圆角半径 `R = min(radius, height/2) + bleed`。

路径顺时针，**起点取「上边左端」**（左上圆角与上边的切点）：

```
M(x0+R, y0) H(x1-R) A R R 0 0 1 (x1, y0+R) V(y1-R)
A R R 0 0 1 (x1-R, y1) H(x0+R) A R R 0 0 1 (x0, y1-R)
V(y0+R) A R R 0 0 1 (x0+R, y0) Z
```

为什么起点必须在「边的端点」而不是中点：起点的选择决定了各条边在路径上是不是**连续段**。起点在中点时，上边被拆成「0→19.6%」和「80.4%→100%」两段，一段虚线永远盖不满整条边。取左端切点后，四条边都是连续区间，动画才能做到「整条边被光带盖满」。

胶囊形（`R = height/2`）时两个 `V` 指令长度为零，路径自动退化成四个圆弧，所以同一份模板同时适配胶囊与普通圆角矩形。

## 长度量（动画的基准）

```
LONG = (x1 - x0) - 2R                      上/下边直线长
CAP  = (y1 - y0) - 2R + πR                 一个「端」的总长（两段四分之一弧 + 中间的直线）
L    = 2·LONG + 2·CAP                      路径总长
```

胶囊 + 默认尺寸（320×44、bleed 2、room 60）时：`LONG = 276`、`CAP = 75.4`、`L = 702.8`。**这三个数是动画的基准**，CSS 里那份兜底 keyframes 就是按它写的。

换成别的尺寸时 `L` 会变（例如 560×120 圆角 18 → `L = 1341.7`），所以 **不能只改 viewBox**，必须让 `rainbow-pill.js` 重算并注入 keyframes。仅缩放 `L` 的比例也不精确 —— 因为 `LONG/CAP` 的比值随卡片比例变化，各段长度需要按几何量分别推导。

## 画布与缩放

`.rb-edge` 的 `inset: calc(-1 * var(--rb-room))` 让它的显示尺寸正好是 `(w + 2·room) × (h + 2·room)`，与 SVG 的 `viewBox` 完全一致 —— 也就是 **1:1 映射，不做任何缩放**。这样 `stdDeviation`、`stroke-width` 这些绝对像素值在任何卡片尺寸下都保持同样的观感粗细；随尺寸变化的只有路径长度和 dash 数值。

## React 接入

`rainbow-pill.js` 里的函数都是纯函数，直接搬进组件即可：

```tsx
const geo = useMemo(() => computeGeometry({ width, height, radius }),
                     [width, height, radius])

useEffect(() => {
  renderEdge(edgeRef.current!, geo)   // 注入 SVG + 按真实路径长度生成 keyframes
}, [geo])
```

JSX 部分照抄演示页的结构（`surface` → `icon/text` → `edge` 的顺序不能变），样式直接 import 同一份 CSS。
