---
name: rainbow-loading-pill
description: 生成「彩虹流光输入框/胶囊」+「沿边框旋转的加载光边」这组成套 UI。当需要做一个带彩色流光边框的输入框、请求条、进度胶囊，或需要让任意尺寸卡片的边缘出现一圈会绕着走、边滑边伸缩的柔光 loading 效果时使用。已完全参数化，支持任意宽高与圆角。
---

# 彩虹输入框 + 加载光边

## 用途

产出两个可独立使用的元素，通常叠在一张卡片上：

1. **彩虹输入框**：白色磨砂面 + 底下旋转的 `conic-gradient` 彩虹光晕，带彩色投影的图标与文本。
2. **加载光边**：一条虚线沿卡片外框绕圈，长边冲过去、左右端减速慢走，同时长度伸缩、粗细变化；用四层不同模糊半径叠加，形成「中间实、外圈散」的柔光。

两者都是纯 CSS + SVG，无第三方依赖，尺寸由参数驱动。

## 何时使用

- 需要「带彩色流光边框的输入框 / 胶囊 / 请求条」。
- 需要「沿着卡片边缘跑一圈的加载光带」（loading 指示，不占位、只发光）。
- 需要把上面两者组合到任意尺寸的卡片上（输入框、卡片、面板都行）。
- 需要调整已有同类效果的：速度节奏、光边粗细、显隐快慢、模糊柔硬。

## 使用方法

1. 复制 `assets/rainbow-pill/` 下的三个文件到目标项目（HTML 部分按框架改写，CSS 与 JS 逻辑原样保留）：
   - `rainbow-pill.css` —— 全部样式与兜底关键帧
   - `rainbow-pill.js` —— 几何计算、关键帧生成、SVG 生成（纯函数，框架无关）
   - `index.html` —— 可直接打开的运行演示（含两个不同尺寸的卡片）
2. 按目标卡片设置尺寸：改 `.rb-slot` 上的 `--rb-w` / `--rb-h`，并把圆角传给 `computeGeometry({ width, height, radius })`。
3. 调用 `renderEdge(edgeEl, geo)` 完成渲染 —— 它会写入 `--rb-room`、替换 SVG、并按**真实路径长度**注入一份 keyframes。
4. 用 `.is-active` 控制显隐（加载开始加上、结束移除）。
5. 用浏览器打开 `index.html` 验证：换几组宽高（例如 320×44、560×120、420×64）确认光边始终贴合边缘、长度变化自然。

**React 接入**：`useMemo` 里调 `computeGeometry`，`useEffect` 里调 `renderEdge`，JSX 结构照抄演示页。细节见 `references/geometry.md`。

## 参数一览

| 参数 | 位置 | 说明 |
|---|---|---|
| `--rb-w` / `--rb-h` | `.rb-slot` | 卡片宽高（唯一尺寸真源） |
| `radius` | `computeGeometry` | 卡片圆角，默认 `height/2`（胶囊） |
| `--rb-bleed` | CSS 默认 2px | 光带中心线相对卡片边缘的外扩量 |
| `--rb-room` | 由 JS 写入 | 画布余量，必须容纳模糊扩散 |
| `--rb-edge-duration` | `.rb-edge` | 光边绕一圈的时间，默认 3s |
| `--rb-rainbow-duration` | `.rb-pill` | 彩虹转一圈的时间，默认 12s |
| `MIN_SPEED` | `rainbow-pill.js` | 光边最小速度（0.15），改完 keyframes 自动重算 |
| `BLUR_STD` | `rainbow-pill.js` | 四层模糊半径 `[0.75, 1.5, 2.5, 4]` |
| `--rb-w-band` / `--rb-w-wide` | CSS 四层 | 长边态（细）/ 圆头态（粗）的绝对像素宽度 |

## 实现要点（改之前先读）

- **起点必须取边的端点**（上边左端切点），不能取中点：否则上边在路径上被拆成两段，一段虚线永远盖不满整条边。
- **dash 数值必须按真实路径长度算**，不存在「只改 viewBox 就自动适配」的写法；只按总长比例整体缩放也不精确，因为长边与端的比值随卡片比例变化。
- **`.rb-edge` 必须位于磨砂面之下**，靠遮挡而非裁剪来去掉内圈；用 `clip-path` 裁会把模糊切出硬边。
- **四层必须画同一条虚线**，只在模糊半径与宽度上分档。让某几层走不同的 dasharray 会在横截面叠出台阶，看起来就是「三条」。
- **不要用 `pathLength` 做归一化**，它在 Chromium 上不可靠；`<rect>` 上更是直接失效。
- 速度曲线的三次项与一次项系数必须满足 `a + b = 1`；抬高最小速度会让峰值同步下降（`峰值 = 3 − 2·最小速度`）。

更多细节：

- 尺寸、路径、层次、React 接入 → `references/geometry.md`
- 速度曲线、关键帧推导、粗细与浓度的取舍 → `references/motion.md`

## 常见坑

| 现象 | 原因 |
|---|---|
| 光边内圈没有被遮住，整圈都亮 | `.rb-edge` 的 z-index 没低于磨砂面；或 `.rb-pill` 缺 `isolation: isolate` 导致彩虹底层跑到卡片背后 |
| 光晕被切成矩形边界 | 用了 CSS `blur()` 而不是 SVG `feGaussianBlur`，或 filter region 太小；`--rb-room` 不够大也会被视口裁掉 |
| 换尺寸后光带缩成一小段或错位 | 仍在用兜底 keyframes（没调 `renderEdge`），dash 数值对不上新的路径长度 |
| 看不出「长边快、圆头慢」 | `MIN_SPEED` 调得太高（接近 0.5 就是全程匀速） |
| 出现明显的分层轮廓 | 有三层以上在画不同长度的 dasharray；合并成一条，只靠模糊分档 |
| 停在某个相位不动 | `animation-play-state: paused` 忘了恢复，或 `animation-delay` 残留（定格截图时常见） |
